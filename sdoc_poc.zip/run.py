import os, argparse, json
from dotenv import load_dotenv
from src.sdoc_poc.log import info, warn, error, get_progress
from src.sdoc_poc.config import Config
from src.sdoc_poc.azure_client import AzureClient
from src.sdoc_poc.store import StateDB
from src.sdoc_poc.ingest import discover_pairs, read_transcript, read_meta
from src.sdoc_poc.lang_detect import detect_language
from src.sdoc_poc.chunker import chunk_text
from src.sdoc_poc.embeddings import ensure_embeddings
from src.sdoc_poc.indexer import export_index
from src.sdoc_poc.evaluator import evaluate_doc, write_report
from src.sdoc_poc.subagent import run_subagent

def step_ingest(cfg: Config, db: StateDB, transcripts_dir: str, meta_dir: str):
    pairs = discover_pairs(transcripts_dir, meta_dir)
    if cfg.max_docs and cfg.max_docs > 0:
        pairs = pairs[:cfg.max_docs]
    info(f"Gefundene Paare: {len(pairs)}")
    with get_progress() as prog:
        task = prog.add_task("Ingest", total=len(pairs))
        for doc_id, t_path, m_path in pairs:
            t_hash = ""
            try:
                t_hash = __import__('src.sdoc_poc.utils', fromlist=['']).utils.file_sha256(t_path)
            except Exception:
                pass
            db.upsert_document(doc_id, t_path, m_path, t_hash)
            text = read_transcript(t_path)
            lang = detect_language(text)
            db.set_language(doc_id, lang)
            chunks = chunk_text(text)
            db.add_chunks(doc_id, chunks)
            prog.update(task, advance=1)

def step_embed(cfg: Config, db: StateDB, client: AzureClient):
    ensure_embeddings(db, cfg, client)

def step_index(cfg: Config, db: StateDB):
    export_index(db, cfg)

def step_eval(cfg: Config, db: StateDB, client: AzureClient):
    docs = db.list_docs(limit=cfg.max_docs or 0)
    by_doc = []
    total_q = 0
    for doc_id in docs:
        _, meta_path = db.doc_paths(doc_id)
        try:
            meta = read_meta(meta_path)
        except Exception:
            meta = {}
        res = evaluate_doc(db, cfg, client, doc_id, meta, max_q=8)
        if res:
            by_doc.append(res)
            total_q += res['n_questions']
    if by_doc:
        avg_score = sum(d['avg_score'] for d in by_doc) / len(by_doc)
        yes_rate = sum(d['yes_rate'] for d in by_doc) / len(by_doc)
    else:
        avg_score = 0.0; yes_rate = 0.0
    stats = {"n_docs": len(by_doc), "n_questions": total_q, "avg_score": avg_score, "yes_rate": yes_rate, "by_doc": by_doc}
    write_report(os.path.join(cfg.artifacts, "report.json"), os.path.join(cfg.artifacts, "report.md"), stats)
    info("Evaluation abgeschlossen -> artifacts/report.md")

def step_subagent(cfg: Config, client: AzureClient):
    path = run_subagent(os.getcwd(), cfg, client)
    info(f"Subagent-Report: {path}")

def main():
    load_dotenv()
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["all","ingest","embed","index","eval","subagent"], help="Pipeline-Schritt oder all")
    parser.add_argument("--transcripts", dest="transcripts", default="data/transcripts", help="Pfad zu Transkripten")
    parser.add_argument("--meta", dest="meta", default="data/meta", help="Pfad zu Meta-Dateien")
    args = parser.parse_args()

    cfg = Config()
    client = AzureClient(cfg)
    db = StateDB(os.path.join(cfg.artifacts, "state.db"))

    if args.command in ("ingest","all"): step_ingest(cfg, db, args.transcripts, args.meta)
    if args.command in ("embed","all"): step_embed(cfg, db, client)
    if args.command in ("index","all"): step_index(cfg, db)
    if args.command in ("eval","all"): step_eval(cfg, db, client)
    if args.command in ("subagent","all"): step_subagent(cfg, client)

if __name__ == "__main__":
    main()
