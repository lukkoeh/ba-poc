import os, json, statistics
from typing import Dict, List, Tuple
from .store import StateDB
from .retrieval import doc_retrieve
from .azure_client import AzureClient
from .config import Config
from .log import info
from .utils import dumps_json

def build_questions_from_meta(meta: dict) -> List[str]:
    out = []
    plan = meta.get("plan", {})
    sections = plan.get("plan", {}).get("sections", []) or plan.get("sections", [])
    for sec in sections:
        for q in sec.get("sample_questions", []) or []:
            out.append(str(q))
    # de-dup
    return list(dict.fromkeys(out))

def evaluate_doc(db: StateDB, cfg: Config, client: AzureClient, doc_id: str, meta: dict, max_q: int = 8):
    questions = build_questions_from_meta(meta)[:max_q]
    if not questions:
        return None
    db.add_questions(doc_id, questions)
    results = []
    for q_id, q in db.doc_questions(doc_id):
        hits = doc_retrieve(db, cfg, client, doc_id, q, top_k=5)
        # judge top-1 context
        ctx = hits[0][3] if hits else ""
        judge = client.judge(q, ctx)
        # record
        if hits:
            chash = hits[0][1]
            db.record_judgment(q_id, chash, cfg.chat_deployment if not cfg.dry_run else "heuristic", judge.get("verdict","NO"), float(judge.get("score",0.0)), judge.get("rationale",""))
        results.append({"question": q, "top1_sim": float(hits[0][0]) if hits else 0.0, **judge})
    # aggregate
    avg_score = statistics.mean([r["score"] for r in results]) if results else 0.0
    yes_rate = sum(1 for r in results if r.get("verdict") == "YES") / max(1, len(results))
    return {"doc_id": doc_id, "n_questions": len(results), "avg_score": avg_score, "yes_rate": yes_rate}

def write_report(path_json: str, path_md: str, stats: Dict):
    with open(path_json, "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2, ensure_ascii=False)
    # markdown
    lines = ["# SDOC PoC Report", "", f"Gesamt-Dokumente: {stats.get('n_docs',0)}", f"Fragen gesamt: {stats.get('n_questions',0)}", f"Durchschnittlicher Score: {stats.get('avg_score',0):.3f}", f"YES-Rate: {stats.get('yes_rate',0):.2%}", "", "## Pro Dokument:"]
    for d in stats.get("by_doc", []):
        lines.append(f"- **{d['doc_id']}** – Q={d['n_questions']}, avg={d['avg_score']:.3f}, YES={d['yes_rate']:.2%}")
    with open(path_md, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
