import os, json, jsonlines
from typing import Dict, List, Tuple, Optional
from .utils import extract_id

def discover_pairs(transcripts_dir: str, meta_dir: str) -> List[Tuple[str,str,str]]:
    """Return list of (doc_id, transcript_path, meta_path)."""
    trans = {}
    for fn in os.listdir(transcripts_dir):
        if fn.startswith("."): continue
        pid = extract_id(fn)
        if not pid: continue
        trans[pid] = os.path.join(transcripts_dir, fn)
    pairs = []
    for fn in os.listdir(meta_dir):
        if fn.startswith("."): continue
        pid = extract_id(fn)
        if not pid: continue
        if pid in trans:
            pairs.append((pid, trans[pid], os.path.join(meta_dir, fn)))
    pairs.sort(key=lambda t: t[0])
    return pairs

def read_transcript(path: str) -> str:
    if path.endswith(".jsonl"):
        texts = []
        with jsonlines.open(path, "r") as reader:
            for obj in reader:
                # Try common keys
                for key in ("text","content","utterance","line"):
                    if key in obj:
                        texts.append(str(obj[key]))
                        break
        return "\n".join(texts)
    elif path.endswith(".json"):
        try:
            with open(path, "r", encoding="utf-8") as f:
                obj = json.load(f)
            if isinstance(obj, list):
                return "\n".join(str(x.get("text","")) for x in obj if isinstance(x, dict))
            if isinstance(obj, dict):
                for key in ("text","content","body"):
                    if key in obj:
                        return str(obj[key])
            return json.dumps(obj, ensure_ascii=False)
        except Exception:
            return ""
    else:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()

def read_meta(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
